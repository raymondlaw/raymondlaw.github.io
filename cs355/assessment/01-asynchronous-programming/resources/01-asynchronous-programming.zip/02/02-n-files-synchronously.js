/*
=======================
02-n-files-synchronously.js
=======================
Student ID:
Comment (Required):

=======================
*/
const fs = require("fs");
const n = 5;	//input size 0 < n < 100
