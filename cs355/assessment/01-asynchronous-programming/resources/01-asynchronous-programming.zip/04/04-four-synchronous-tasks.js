/*
=======================
04-four-synchronous-tasks.js
=======================
Student ID:
Comment (Required):

=======================
*/
const fs = require("fs");
const dns = require("dns");
const zlib = require("zlib");
const input_file = "./input/domain.deflated";
const output_file = "./output/ip_address.txt";
