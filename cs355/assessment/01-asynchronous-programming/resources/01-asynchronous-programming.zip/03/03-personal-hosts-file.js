/*
=======================
03-personal-hosts-file.js
=======================
Student ID:
Comment (Required):

=======================
*/
const fs = require("fs");
const dns = require("dns");
const input_file = "./input/domains.txt";
const output_file = "./output/hosts.txt";

