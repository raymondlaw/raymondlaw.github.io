const https = require("https");
const options = {
    method:"GET",
    headers:{
        "User-Agent":"nodejs",
    }
}
process.stdin.on("data", chunk => getDefinition(chunk));
function getDefinition(word){
    const url = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;
    const myreq = https.request(url, options);
    myreq.end();
    myreq.on("response", (jsonStream)=>{
        let jsonBody = "";
        jsonStream.on("data", chunk => jsonBody += chunk);
        jsonStream.on("end" , ()=>{
            const defObj = JSON.parse(jsonBody);
            const firstDef = defObj[0]?.meanings[0]?.definitions[0]?.definition;
            (firstDef === undefined) ? console.log("[No Definitions Found]") : console.log(firstDef);
        })
    });
}